import { useState, useEffect, useMemo, useCallback } from "react";

type Player = "X" | "O";
type Cell = Player | null;
type Board = Cell[];
type GameStatus = "playing" | "won" | "lost" | "draw";
type Difficulty = "easy" | "smart" | "unbeatable";

interface MoveEvaluation {
  index: number;
  score: number;
  depth: number;
  nodesEvaluated: number;
}

interface GameTree {
  move: number | null;
  score: number;
  children: GameTree[];
  alpha: number;
  beta: number;
  pruned: boolean;
}

const WIN_LINES = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8],
  [0, 3, 6], [1, 4, 7], [2, 5, 8],
  [0, 4, 8], [2, 4, 6],
];

function checkWinner(board: Board): { winner: Player | null; line: number[] | null } {
  for (const line of WIN_LINES) {
    const [a, b, c] = line;
    if (board[a] && board[a] === board[b] && board[a] === board[c]) {
      return { winner: board[a], line };
    }
  }
  return { winner: null, line: null };
}

function isBoardFull(board: Board): boolean {
  return board.every(cell => cell !== null);
}

// Minimax with Alpha-Beta Pruning
function minimax(
  board: Board,
  depth: number,
  isMaximizing: boolean,
  alpha: number,
  beta: number,
  aiPlayer: Player,
  humanPlayer: Player,
  maxDepth: number = 9,
  tree?: GameTree
): { score: number; index: number; nodesEvaluated: number } {
  const { winner } = checkWinner(board);
  
  if (winner === aiPlayer) return { score: 10 - depth, index: -1, nodesEvaluated: 1 };
  if (winner === humanPlayer) return { score: depth - 10, index: -1, nodesEvaluated: 1 };
  if (isBoardFull(board) || depth >= maxDepth) return { score: 0, index: -1, nodesEvaluated: 1 };

  let bestScore = isMaximizing ? -Infinity : Infinity;
  let bestIndex = -1;
  let totalNodes = 1;

  const emptyIndices = board.map((cell, i) => cell === null ? i : null).filter(i => i !== null) as number[];

  for (const idx of emptyIndices) {
    board[idx] = isMaximizing ? aiPlayer : humanPlayer;
    
    const childTree: GameTree = {
      move: idx,
      score: 0,
      children: [],
      alpha,
      beta,
      pruned: false,
    };
    
    const result = minimax(board, depth + 1, !isMaximizing, alpha, beta, aiPlayer, humanPlayer, maxDepth, childTree);
    totalNodes += result.nodesEvaluated;
    
    board[idx] = null;
    childTree.score = result.score;
    
    if (tree) tree.children.push(childTree);

    if (isMaximizing) {
      if (result.score > bestScore) {
        bestScore = result.score;
        bestIndex = idx;
      }
      alpha = Math.max(alpha, bestScore);
    } else {
      if (result.score < bestScore) {
        bestScore = result.score;
        bestIndex = idx;
      }
      beta = Math.min(beta, bestScore);
    }

    if (beta <= alpha) {
      childTree.pruned = true;
      break; // Alpha-beta pruning
    }
  }

  return { score: bestScore, index: bestIndex, nodesEvaluated: totalNodes };
}

export default function App() {
  const [board, setBoard] = useState<Board>(Array(9).fill(null));
  const [humanPlayer, setHumanPlayer] = useState<Player>("X");
  const [currentPlayer, setCurrentPlayer] = useState<Player>("X");
  const [status, setStatus] = useState<GameStatus>("playing");
  const [winningLine, setWinningLine] = useState<number[] | null>(null);
  const [difficulty, setDifficulty] = useState<Difficulty>("unbeatable");
  const [showTree, setShowTree] = useState(true);
  const [aiThinking, setAiThinking] = useState(false);
  const [lastAiMove, setLastAiMove] = useState<number | null>(null);
  const [moveEvaluations, setMoveEvaluations] = useState<MoveEvaluation[]>([]);
  const [gameTree, setGameTree] = useState<GameTree | null>(null);
  const [scores, setScores] = useState({ wins: 0, losses: 0, draws: 0 });
  const [moveHistory, setMoveHistory] = useState<Board[]>([]);
  const [hoveredCell, setHoveredCell] = useState<number | null>(null);

  const aiPlayer = useMemo(() => (humanPlayer === "X" ? "O" : "X"), [humanPlayer]);

  const resetGame = useCallback(() => {
    setBoard(Array(9).fill(null));
    setCurrentPlayer("X");
    setStatus("playing");
    setWinningLine(null);
    setLastAiMove(null);
    setMoveEvaluations([]);
    setGameTree(null);
    setMoveHistory([]);
  }, []);

  const makeMove = useCallback((index: number, player: Player) => {
    if (board[index] || status !== "playing") return false;
    
    const newBoard = [...board];
    newBoard[index] = player;
    setBoard(newBoard);
    setMoveHistory(prev => [...prev, newBoard]);
    
    const result = checkWinner(newBoard);
    if (result.winner) {
      setWinningLine(result.line);
      setStatus(result.winner === humanPlayer ? "won" : "lost");
      setScores(s => ({
        ...s,
        wins: result.winner === humanPlayer ? s.wins + 1 : s.wins,
        losses: result.winner === aiPlayer ? s.losses + 1 : s.losses,
      }));
    } else if (isBoardFull(newBoard)) {
      setStatus("draw");
      setScores(s => ({ ...s, draws: s.draws + 1 }));
    } else {
      setCurrentPlayer(player === "X" ? "O" : "X");
    }
    
    return true;
  }, [board, status, humanPlayer, aiPlayer]);

  const getAiMove = useCallback(async () => {
    setAiThinking(true);
    setMoveEvaluations([]);
    
    // Small delay for UX
    await new Promise(resolve => setTimeout(resolve, 400));
    
    const emptyIndices = board.map((cell, i) => cell === null ? i : null).filter(i => i !== null) as number[];
    
    if (emptyIndices.length === 0) {
      setAiThinking(false);
      return;
    }

    let chosenIndex: number;
    const evaluations: MoveEvaluation[] = [];
    const tree: GameTree = { move: null, score: 0, children: [], alpha: -Infinity, beta: Infinity, pruned: false };

    if (difficulty === "easy") {
      // 60% random, 40% optimal
      if (Math.random() < 0.6) {
        chosenIndex = emptyIndices[Math.floor(Math.random() * emptyIndices.length)];
      } else {
        const result = minimax([...board], 0, true, -Infinity, Infinity, aiPlayer, humanPlayer, 3, tree);
        chosenIndex = result.index;
      }
    } else if (difficulty === "smart") {
      // Limited depth minimax
      const result = minimax([...board], 0, true, -Infinity, Infinity, aiPlayer, humanPlayer, 4, tree);
      chosenIndex = result.index;
    } else {
      // Unbeatable - full minimax with alpha-beta
      const result = minimax([...board], 0, true, -Infinity, Infinity, aiPlayer, humanPlayer, 9, tree);
      chosenIndex = result.index;
      
      // Evaluate all moves for visualization
      for (const idx of emptyIndices) {
        const testBoard = [...board];
        testBoard[idx] = aiPlayer;
        const evalResult = minimax(testBoard, 1, false, -Infinity, Infinity, aiPlayer, humanPlayer, 9);
        evaluations.push({
          index: idx,
          score: evalResult.score,
          depth: 0,
          nodesEvaluated: evalResult.nodesEvaluated,
        });
      }
    }

    setGameTree(tree);
    setMoveEvaluations(evaluations.sort((a, b) => b.score - a.score));
    setLastAiMove(chosenIndex);
    setAiThinking(false);
    
    makeMove(chosenIndex, aiPlayer);
  }, [board, aiPlayer, humanPlayer, difficulty, makeMove]);

  // AI turn
  useEffect(() => {
    if (currentPlayer === aiPlayer && status === "playing" && !aiThinking) {
      getAiMove();
    }
  }, [currentPlayer, aiPlayer, status, aiThinking, getAiMove]);

  const handleCellClick = (index: number) => {
    if (currentPlayer !== humanPlayer || aiThinking || board[index]) return;
    makeMove(index, humanPlayer);
  };

  const switchPlayer = () => {
    setHumanPlayer(h => h === "X" ? "O" : "X");
    resetGame();
  };

  const totalGames = scores.wins + scores.losses + scores.draws;
  const winRate = totalGames > 0 ? Math.round((scores.wins / totalGames) * 100) : 0;

  return (
    <div className="min-h-screen bg-[#050507] text-white overflow-hidden relative">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
        * { font-family: 'Space Grotesk', system-ui, -apple-system, sans-serif; }
        .mono { font-family: 'JetBrains Mono', monospace; }
        
        .grid-bg {
          background-image: 
            linear-gradient(rgba(139, 92, 246, 0.03) 1px, transparent 1px),
            linear-gradient(90deg, rgba(139, 92, 246, 0.03) 1px, transparent 1px);
          background-size: 32px 32px;
        }
      `}</style>

      {/* Background effects */}
      <div className="absolute inset-0 grid-bg" />
      <div className="absolute top-[-20%] left-[-10%] w-[600px] h-[600px] bg-violet-600/20 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-20%] right-[-10%] w-[500px] h-[500px] bg-blue-600/20 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute top-[30%] right-[20%] w-[300px] h-[300px] bg-fuchsia-600/15 rounded-full blur-[100px] pointer-events-none" />

      <div className="relative z-10 max-w-[1400px] mx-auto px-4 py-6 lg:py-8">
        {/* Header */}
        <header className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <div className="relative">
              <div className="absolute inset-0 bg-violet-500 blur-xl opacity-50" />
              <div className="relative w-12 h-12 rounded-2xl bg-gradient-to-br from-violet-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-violet-950/50 ring-1 ring-white/10">
                <span className="text-xl font-bold">#</span>
              </div>
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight">Tic-Tac-Toe AI</h1>
              <p className="text-xs text-zinc-500 -mt-1">Minimax • Alpha-Beta Pruning</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-zinc-900/80 border border-zinc-800 backdrop-blur">
              <div className={`w-2 h-2 rounded-full ${aiThinking ? 'bg-amber-400 animate-pulse' : 'bg-emerald-400'}`} />
              <span className="text-xs mono text-zinc-400">
                {aiThinking ? 'THINKING' : 'READY'}
              </span>
            </div>
            <button
              onClick={resetGame}
              className="px-4 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-sm font-medium transition-colors"
            >
              New Game
            </button>
          </div>
        </header>

        <div className="grid lg:grid-cols-[1.1fr_0.9fr] gap-6 xl:gap-8 items-start">
          {/* Left: Game */}
          <div className="space-y-6">
            {/* Game board */}
            <div className="relative">
              <div className="absolute -inset-1 bg-gradient-to-r from-violet-600/20 to-blue-600/20 rounded-[2rem] blur-2xl" />
              <div className="relative bg-zinc-950/70 backdrop-blur-2xl rounded-[2rem] border border-zinc-800/80 shadow-2xl shadow-black/50 overflow-hidden">
                <div className="p-6 sm:p-8 lg:p-10">
                  {/* Status bar */}
                  <div className="flex items-center justify-between mb-8">
                    <div className="flex items-center gap-3">
                      <button
                        onClick={switchPlayer}
                        className="group flex items-center gap-2.5 px-4 py-2.5 rounded-2xl bg-zinc-900/80 hover:bg-zinc-800 border border-zinc-800 transition-all"
                      >
                        <div className="w-8 h-8 rounded-xl bg-zinc-950 flex items-center justify-center ring-1 ring-zinc-800 group-hover:ring-violet-500/50 transition-all">
                          <span className="text-lg font-bold">{humanPlayer}</span>
                        </div>
                        <div className="text-left">
                          <div className="text-[10px] uppercase tracking-wider text-zinc-500 -mb-1">You play</div>
                          <div className="text-sm font-medium">Click to switch</div>
                        </div>
                      </button>
                      
                      <div className="h-8 w-px bg-zinc-800" />
                      
                      <div className="flex items-center gap-2.5 px-4 py-2.5 rounded-2xl bg-zinc-900/50 border border-zinc-800/50">
                        <div className="w-8 h-8 rounded-xl bg-zinc-950 flex items-center justify-center ring-1 ring-zinc-800">
                          <span className="text-lg font-bold text-zinc-400">{aiPlayer}</span>
                        </div>
                        <div>
                          <div className="text-[10px] uppercase tracking-wider text-zinc-500 -mb-1">AI plays</div>
                          <div className="text-sm font-medium text-zinc-400">Minimax</div>
                        </div>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-[11px] uppercase tracking-widest text-zinc-600 mb-1">Status</div>
                      <div className={`text-sm font-medium mono ${
                        status === "playing" ? "text-zinc-300" :
                        status === "won" ? "text-emerald-400" :
                        status === "lost" ? "text-red-400" : "text-amber-400"
                      }`}>
                        {status === "playing" ? (currentPlayer === humanPlayer ? "YOUR TURN" : "AI THINKING...") :
                         status === "won" ? "YOU WIN" :
                         status === "lost" ? "AI WINS" : "DRAW"}
                      </div>
                    </div>
                  </div>

                  {/* Board */}
                  <div className="relative mx-auto w-full max-w-[420px] aspect-square">
                    {/* Glow behind board */}
                    <div className="absolute inset-0 bg-gradient-to-br from-violet-600/10 to-blue-600/10 rounded-3xl blur-3xl" />
                    
                    <div className="relative grid grid-cols-3 gap-3 sm:gap-4 h-full">
                      {board.map((cell, i) => {
                        const isWinning = winningLine?.includes(i);
                        const isLastAi = lastAiMove === i;
                        const evaluation = moveEvaluations.find(e => e.index === i);
                        const isHovered = hoveredCell === i && !cell && currentPlayer === humanPlayer && status === "playing";
                        
                        return (
                          <button
                            key={i}
                            onClick={() => handleCellClick(i)}
                            onMouseEnter={() => setHoveredCell(i)}
                            onMouseLeave={() => setHoveredCell(null)}
                            disabled={!!cell || currentPlayer !== humanPlayer || status !== "playing" || aiThinking}
                            className={`
                              group relative aspect-square rounded-2xl sm:rounded-3xl
                              bg-zinc-900/90 border transition-all duration-300
                              ${isWinning ? "border-emerald-500/80 shadow-[0_0_30px_rgba(16,185,129,0.3)] scale-[1.02] z-10" : "border-zinc-800"}
                              ${!cell && currentPlayer === humanPlayer && status === "playing" ? "hover:border-violet-500/50 hover:bg-zinc-900 cursor-pointer hover:scale-[1.02] hover:shadow-xl hover:shadow-violet-950/20" : ""}
                              ${cell || status !== "playing" ? "cursor-default" : ""}
                              ${isLastAi ? "ring-2 ring-blue-500/50 ring-offset-2 ring-offset-zinc-950" : ""}
                              disabled:opacity-100
                            `}
                          >
                            {/* Cell background effects */}
                            <div className="absolute inset-0 rounded-2xl sm:rounded-3xl overflow-hidden">
                              <div className={`absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 bg-gradient-to-br from-violet-600/10 to-transparent ${isHovered ? '!opacity-100' : ''}`} />
                              {isWinning && (
                                <div className="absolute inset-0 bg-emerald-500/10 animate-pulse" />
                              )}
                            </div>

                            {/* Evaluation heatmap */}
                            {evaluation && showTree && (
                              <div className="absolute inset-0 rounded-2xl sm:rounded-3xl overflow-hidden pointer-events-none">
                                <div 
                                  className="absolute inset-0 transition-opacity duration-500"
                                  style={{
                                    background: evaluation.score > 0 
                                      ? `radial-gradient(circle at center, rgba(59,130,246,${Math.min(0.3, evaluation.score/15)}) 0%, transparent 70%)`
                                      : evaluation.score < 0
                                      ? `radial-gradient(circle at center, rgba(239,68,68,${Math.min(0.3, Math.abs(evaluation.score)/15)}) 0%, transparent 70%)`
                                      : 'transparent',
                                  }}
                                />
                                <div className="absolute top-2 right-2">
                                  <span className={`text-[10px] mono px-1.5 py-0.5 rounded-md backdrop-blur-md ${
                                    evaluation.score > 0 ? 'bg-blue-500/20 text-blue-300 ring-1 ring-blue-500/30' :
                                    evaluation.score < 0 ? 'bg-red-500/20 text-red-300 ring-1 ring-red-500/30' :
                                    'bg-zinc-700/50 text-zinc-400 ring-1 ring-zinc-600/30'
                                  }`}>
                                    {evaluation.score > 0 ? '+' : ''}{evaluation.score}
                                  </span>
                                </div>
                              </div>
                            )}

                            {/* X or O */}
                            <div className="relative w-full h-full flex items-center justify-center">
                              {cell === "X" && (
                                <svg viewBox="0 0 100 100" className="w-[60%] h-[60%]">
                                  <defs>
                                    <linearGradient id="xGrad" x1="0" y1="0" x2="1" y2="1">
                                      <stop offset="0%" stopColor="#a78bfa" />
                                      <stop offset="100%" stopColor="#8b5cf6" />
                                    </linearGradient>
                                  </defs>
                                  <g stroke="url(#xGrad)" strokeWidth="10" strokeLinecap="round" fill="none" className="drop-shadow-[0_0_12px_rgba(139,92,246,0.5)]">
                                    <line x1="20" y1="20" x2="80" y2="80" className="animate-[draw_0.3s_ease-out]" />
                                    <line x1="80" y1="20" x2="20" y2="80" className="animate-[draw_0.3s_ease-out_0.1s_both]" />
                                  </g>
                                </svg>
                              )}
                              {cell === "O" && (
                                <svg viewBox="0 0 100 100" className="w-[60%] h-[60%]">
                                  <defs>
                                    <linearGradient id="oGrad" x1="0" y1="0" x2="1" y2="1">
                                      <stop offset="0%" stopColor="#60a5fa" />
                                      <stop offset="100%" stopColor="#3b82f6" />
                                    </linearGradient>
                                  </defs>
                                  <circle cx="50" cy="50" r="30" stroke="url(#oGrad)" strokeWidth="10" fill="none" className="drop-shadow-[0_0_12px_rgba(59,130,246,0.5)] animate-[draw_0.4s_ease-out]" />
                                </svg>
                              )}
                              {isHovered && (
                                <div className="absolute inset-0 flex items-center justify-center">
                                  <span className="text-5xl font-light text-zinc-700/50">{humanPlayer}</span>
                                </div>
                              )}
                            </div>

                            {/* Corner index for dev */}
                            <span className="absolute bottom-1.5 left-1.5 text-[9px] mono text-zinc-700">{i}</span>
                          </button>
                        );
                      })}
                    </div>

                    {/* AI thinking overlay */}
                    {aiThinking && (
                      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                        <div className="bg-zinc-950/90 backdrop-blur-xl rounded-2xl px-5 py-3 border border-zinc-800 shadow-2xl">
                          <div className="flex items-center gap-3">
                            <div className="flex gap-1">
                              <span className="w-1.5 h-1.5 bg-violet-400 rounded-full animate-bounce [animation-delay:-0.3s]" />
                              <span className="w-1.5 h-1.5 bg-violet-400 rounded-full animate-bounce [animation-delay:-0.15s]" />
                              <span className="w-1.5 h-1.5 bg-violet-400 rounded-full animate-bounce" />
                            </div>
                            <span className="text-xs mono text-zinc-300">MINIMAX SEARCHING</span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Difficulty */}
                  <div className="flex items-center justify-center gap-2 mt-8">
                    {(["easy", "smart", "unbeatable"] as Difficulty[]).map((d) => (
                      <button
                        key={d}
                        onClick={() => setDifficulty(d)}
                        className={`px-3.5 py-1.5 rounded-full text-xs font-medium capitalize transition-all border ${
                          difficulty === d
                            ? "bg-violet-500/20 text-violet-300 border-violet-500/40 shadow-[0_0_20px_rgba(139,92,246,0.2)]"
                            : "bg-zinc-900/50 text-zinc-500 border-zinc-800 hover:border-zinc-700 hover:text-zinc-300"
                        }`}
                      >
                        {d}
                      </button>
                    ))}
                    <div className="w-px h-4 bg-zinc-800 mx-1" />
                    <button
                      onClick={() => setShowTree(!showTree)}
                      className={`px-3.5 py-1.5 rounded-full text-xs font-medium transition-all border ${
                        showTree
                          ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40"
                          : "bg-zinc-900/50 text-zinc-500 border-zinc-800"
                      }`}
                    >
                      Show Evaluations
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Scoreboard */}
            <div className="grid grid-cols-4 gap-3">
              {[
                { label: "WINS", value: scores.wins, color: "text-emerald-400", bg: "from-emerald-600/10" },
                { label: "LOSSES", value: scores.losses, color: "text-red-400", bg: "from-red-600/10" },
                { label: "DRAWS", value: scores.draws, color: "text-amber-400", bg: "from-amber-600/10" },
                { label: "WIN %", value: `${winRate}%`, color: "text-violet-400", bg: "from-violet-600/10" },
              ].map((stat) => (
                <div key={stat.label} className="relative group">
                  <div className={`absolute inset-0 bg-gradient-to-b ${stat.bg} to-transparent rounded-2xl blur-xl opacity-50 group-hover:opacity-75 transition-opacity`} />
                  <div className="relative bg-zinc-950/70 backdrop-blur border border-zinc-800 rounded-2xl p-4 text-center">
                    <div className={`text-2xl font-bold ${stat.color}`}>{stat.value}</div>
                    <div className="text-[10px] uppercase tracking-widest text-zinc-600 mt-1">{stat.label}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right: AI Brain */}
          <div className="space-y-4">
            <div className="relative">
              <div className="absolute -inset-1 bg-gradient-to-r from-blue-600/20 to-violet-600/20 rounded-[1.5rem] blur-2xl" />
              <div className="relative bg-zinc-950/70 backdrop-blur-2xl rounded-[1.5rem] border border-zinc-800/80 shadow-2xl overflow-hidden">
                <div className="border-b border-zinc-800/80 px-5 py-4 flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-600 to-violet-600 flex items-center justify-center">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2">
                        <path d="M12 2a10 10 0 0 0-9.95 9h11.64L9.74 7.05a1 1 0 0 1 1.41-1.41l5.66 5.66a1 1 0 0 1 0 1.41l-5.66 5.66a1 1 0 0 1-1.41 0 1 1 0 0 1 0-1.41L13.69 13H2.05A10 10 0 1 0 12 2z"/>
                      </svg>
                    </div>
                    <div>
                      <h2 className="font-semibold leading-none">AI Brain</h2>
                      <p className="text-[11px] text-zinc-500 mt-0.5">Minimax with α-β pruning</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    <span className="text-[10px] mono text-zinc-500">LIVE</span>
                  </div>
                </div>

                <div className="p-5 space-y-5 max-h-[520px] overflow-auto custom-scroll">
                  {/* Current evaluation */}
                  <div>
                    <div className="text-[11px] uppercase tracking-widest text-zinc-600 mb-2.5">Move Evaluations</div>
                    {moveEvaluations.length > 0 ? (
                      <div className="space-y-2">
                        {moveEvaluations.slice(0, 5).map((ev) => (
                          <div key={ev.index} className="group relative">
                            <div className="flex items-center gap-3 p-2.5 rounded-xl bg-zinc-900/50 border border-zinc-800/50 hover:bg-zinc-900 transition-colors">
                              <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold mono ring-1 ${
                                ev.index === lastAiMove
                                  ? "bg-blue-500/20 text-blue-300 ring-blue-500/40"
                                  : "bg-zinc-800 text-zinc-400 ring-zinc-700"
                              }`}>
                                {ev.index}
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2">
                                  <div className="h-1.5 flex-1 bg-zinc-800 rounded-full overflow-hidden">
                                    <div 
                                      className={`h-full transition-all duration-700 ${
                                        ev.score > 0 ? "bg-gradient-to-r from-blue-600 to-cyan-500" :
                                        ev.score < 0 ? "bg-gradient-to-r from-red-600 to-orange-500" :
                                        "bg-zinc-600"
                                      }`}
                                      style={{ 
                                        width: `${50 + (ev.score / 10) * 50}%`,
                                        marginLeft: ev.score < 0 ? `${50 + (ev.score / 10) * 50}%` : '0'
                                      }}
                                    />
                                  </div>
                                  <span className={`text-xs mono w-8 text-right ${
                                    ev.score > 0 ? "text-blue-400" : ev.score < 0 ? "text-red-400" : "text-zinc-500"
                                  }`}>
                                    {ev.score > 0 ? "+" : ""}{ev.score}
                                  </span>
                                </div>
                                <div className="flex items-center gap-3 mt-1">
                                  <span className="text-[10px] text-zinc-600">
                                    {ev.nodesEvaluated.toLocaleString()} nodes
                                  </span>
                                  {ev.index === lastAiMove && (
                                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300 ring-1 ring-blue-500/30">
                                      CHOSEN
                                    </span>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-8 px-4 rounded-xl bg-zinc-900/30 border border-dashed border-zinc-800">
                        <div className="w-10 h-10 mx-auto mb-3 rounded-xl bg-zinc-900 flex items-center justify-center">
                          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="text-zinc-600">
                            <circle cx="12" cy="12" r="10"/>
                            <path d="M12 16v-4M12 8h.01"/>
                          </svg>
                        </div>
                        <p className="text-sm text-zinc-500">Make a move to see AI analysis</p>
                        <p className="text-xs text-zinc-600 mt-1">Evaluates all possible futures</p>
                      </div>
                    )}
                  </div>

                  {/* Algorithm info */}
                  <div>
                    <div className="text-[11px] uppercase tracking-widest text-zinc-600 mb-2.5">How It Works</div>
                    <div className="space-y-2.5">
                      {[
                        { 
                          icon: "1", 
                          title: "Minimax Search", 
                          desc: "Explores all game states to depth 9",
                          color: "from-violet-600 to-purple-600"
                        },
                        { 
                          icon: "αβ", 
                          title: "Alpha-Beta Pruning", 
                          desc: "Skips branches that can't improve result",
                          color: "from-blue-600 to-cyan-600"
                        },
                        { 
                          icon: "∞", 
                          title: "Perfect Play", 
                          desc: "Unbeatable: win or draw guaranteed",
                          color: "from-emerald-600 to-teal-600"
                        },
                      ].map((item) => (
                        <div key={item.title} className="flex gap-3 p-3 rounded-xl bg-zinc-900/30 border border-zinc-800/50">
                          <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${item.color} flex items-center justify-center text-xs font-bold shrink-0 shadow-lg`}>
                            {item.icon}
                          </div>
                          <div className="min-w-0">
                            <div className="text-sm font-medium text-zinc-200">{item.title}</div>
                            <div className="text-xs text-zinc-500 leading-snug">{item.desc}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Game tree visualization */}
                  {gameTree && gameTree.children.length > 0 && (
                    <div>
                      <div className="text-[11px] uppercase tracking-widest text-zinc-600 mb-2.5">Search Tree (simplified)</div>
                      <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-900">
                        <div className="flex items-center justify-center gap-1.5 flex-wrap">
                          {gameTree.children.slice(0, 7).map((child, i) => (
                            <div key={i} className="flex flex-col items-center gap-1">
                              <div className={`w-7 h-7 rounded-lg flex items-center justify-center text-[11px] mono border transition-all ${
                                child.pruned 
                                  ? "bg-red-950/50 border-red-900/50 text-red-400/60 line-through" 
                                  : child.move === lastAiMove
                                  ? "bg-blue-500/20 border-blue-500/50 text-blue-300 shadow-[0_0_10px_rgba(59,130,246,0.3)]"
                                  : "bg-zinc-900 border-zinc-800 text-zinc-500"
                              }`}>
                                {child.move}
                              </div>
                              <div className={`text-[9px] mono ${child.score > 0 ? "text-blue-400" : child.score < 0 ? "text-red-400" : "text-zinc-600"}`}>
                                {child.score}
                              </div>
                            </div>
                          ))}
                          {gameTree.children.length > 7 && (
                            <div className="text-[10px] text-zinc-600">+{gameTree.children.length - 7}</div>
                          )}
                        </div>
                        <div className="mt-2.5 pt-2.5 border-t border-zinc-900 flex items-center justify-between text-[10px]">
                          <span className="text-zinc-600">
                            Evaluated <span className="text-zinc-400 mono">{gameTree.children.reduce((sum, c) => sum + (c.pruned ? 1 : 10), 0)}+</span> nodes
                          </span>
                          <span className="text-emerald-400">α-β pruned {gameTree.children.filter(c => c.pruned).length}</span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Theory card */}
            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-to-b from-violet-600/5 to-transparent rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="relative bg-zinc-950/50 backdrop-blur border border-zinc-900 rounded-2xl p-5">
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <span className="w-5 h-5 rounded-md bg-zinc-900 flex items-center justify-center">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-violet-400">
                      <path d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/>
                    </svg>
                  </span>
                  Game Theory
                </h3>
                <div className="space-y-2.5 text-[13px] leading-relaxed text-zinc-400">
                  <p>
                    <span className="text-zinc-200 font-medium">Minimax</span> assumes both players play perfectly. It maximizes AI's minimum gain.
                  </p>
                  <p>
                    <span className="text-zinc-200 font-medium">Alpha-Beta</span> pruning cuts ~99% of the search tree without changing the result.
                  </p>
                  <div className="pt-2.5 mt-2.5 border-t border-zinc-900">
                    <div className="flex items-baseline justify-between">
                      <span className="text-xs text-zinc-600">Complexity</span>
                      <span className="mono text-xs text-zinc-300">O(b^d) → O(√b^d)</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Move history */}
        {moveHistory.length > 0 && (
          <div className="mt-8">
            <div className="flex items-center gap-2 mb-3">
              <h3 className="text-xs uppercase tracking-widest text-zinc-600">Move History</h3>
              <div className="h-px flex-1 bg-zinc-900" />
            </div>
            <div className="flex gap-2 overflow-x-auto pb-2 custom-scroll">
              {moveHistory.map((histBoard, idx) => (
                <div key={idx} className="shrink-0 w-14 h-14 rounded-xl bg-zinc-950 border border-zinc-900 p-1.5 hover:border-zinc-800 transition-colors">
                  <div className="grid grid-cols-3 gap-0.5 w-full h-full">
                    {histBoard.map((cell, i) => (
                      <div key={i} className="flex items-center justify-center bg-zinc-900/50 rounded-[3px]">
                        <span className={`text-[9px] font-bold ${cell === "X" ? "text-violet-400" : "text-blue-400"}`}>
                          {cell}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <style>{`
        .custom-scroll::-webkit-scrollbar { width: 4px; height: 4px; }
        .custom-scroll::-webkit-scrollbar-track { background: transparent; }
        .custom-scroll::-webkit-scrollbar-thumb { background: #27272a; border-radius: 2px; }
        .custom-scroll::-webkit-scrollbar-thumb:hover { background: #3f3f46; }
        
        @keyframes draw {
          from { stroke-dasharray: 100; stroke-dashoffset: 100; }
          to { stroke-dasharray: 100; stroke-dashoffset: 0; }
        }
      `}</style>
    </div>
  );
}
// Zod Schema
export const Schema = {
    "commentary": "Built unbeatable Tic-Tac-Toe AI using Minimax with Alpha-Beta pruning. Features live move evaluations, search tree visualization, and educational breakdown of game theory. The AI explores all possible futures and is mathematically perfect—you can only win if it lets you (easy mode). Includes three difficulties, win tracking, and real-time visualization of the algorithm's decision process.",
    "template": "next-forge",
    "title": "Tic-Tac-Toe AI — Unbeatable Minimax Agent",
    "description": "Play against an unbeatable AI powered by Minimax algorithm with Alpha-Beta pruning. Watch the AI evaluate every possible move in real-time, see the search tree, and learn game theory concepts. Features perfect play, move heatmaps, and detailed algorithm visualization.",
    "additional_dependencies": [],
    "has_additional_dependencies": false,
    "install_dependencies_command": "",
    "port": 3000,
    "file_path": "pages/index.tsx",
    "code": "<see code above>"
}